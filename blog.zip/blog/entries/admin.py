from django.contrib import admin
from .models import Entry
 
admin.site.register(Entry) # Регистрируем модель.
